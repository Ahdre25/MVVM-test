//
//  AuthorizationNetwork.swift
//  MVVM test
//
//  Created by Fox on 11.09.2025.
//

class AuthorizationNetwork {
    
}
