//
//  AuthorizationView.swift
//  MVVM test
//
//  Created by Fox on 11.09.2025.
//

import SwiftUI


struct AuthorizationContainerView: View {
    // Родитель ВЛАДЕЕТ и стабилизирует инстансы
    @StateObject private var flow = AuthorizationFlowModel()
    @StateObject private var vm   = AuthorizationViewModel()

    var body: some View {
        AuthorizationView(flow: flow, viewModel: vm)
    }
}


struct AuthorizationView: View {
    
    @StateObject var flow: AuthorizationFlowModel = AuthorizationFlowModel()
    @StateObject var viewModel: AuthorizationViewModel

    var body: some View {
        NavigationStack(path: $flow.path) {
            VStack {
                TextField("Логин", text: $viewModel.username)
                TextField("Пароль", text: $viewModel.password)
                Button("Войти") {
//                    flow.openSettings()
                    viewModel.authorizationTap()
                }
                
                
            }.padding().lineSpacing(18)
                .navigationDestination(for: AuthorizationRoute.self, destination: { route in
                switch(route) {
                case .settings:
                    PaymentView(viewModel: PaymentViewModel())
                case .detail(id: let id):
                    AuthorizationView(viewModel: AuthorizationViewModel())
                }
                
            })
        }.onAppear {
            viewModel.onAuthorizationSuccess = {
                flow.openSettings()
            }
        }
    }
    
    
    
    
}

#Preview {
    AuthorizationView(viewModel: AuthorizationViewModel())
}
