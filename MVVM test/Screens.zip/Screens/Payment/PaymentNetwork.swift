//
//  PaymentNetwork.swift
//  MVVM test
//
//  Created by Fox on 12.09.2025
//

import Foundation

class PaymentNetwork {
    
}
